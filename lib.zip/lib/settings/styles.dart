import 'package:flutter/material.dart';

class StylesApp {
  static Color appPrimaryColor = Color.fromARGB(255, 6, 126, 122);
}
